# Test Cases — PS No. 77

Each test case should begin with the original `workload.csv` data supplied with the project. If a previous test saved changes, restore the original six rows before starting the next case.

## Test Case 1: Normal input — Show workload summary

Menu choice: `1`

Expected output:

```text
Dr. Sharma : 11 hours (5 free)
Dr. Verma : 18 hours - OVERLOADED by 2 hours
Dr. Iyer : 4 hours (12 free)
```

## Test Case 2: Boundary / minimum input — Assign subject

Menu choice: `2`

Inputs:
- Faculty: `Dr. Sharma`
- Subject: `Python Lab`
- Hours: `5`

Expected output:

```text
Assigned. Dr. Sharma now has 16 hours (limit reached).
```

## Test Case 3(a): Invalid assignment — Exceeds limit

Menu choice: `2`

Inputs:
- Faculty: `Dr. Sharma`
- Subject: `Statistics`
- Hours: `7`

Expected output:

```text
Cannot assign: Dr. Sharma would have 18 hours, exceeding the 16-hour limit.
```

## Test Case 3(b): Invalid assignment — Negative hours

Menu choice: `2`

Inputs:
- Faculty: `Dr. Iyer`
- Subject: `Python Lab`
- Hours: `-2`

Expected output:

```text
Hours must be a positive whole number.
```

## Test Case 4: Find faculty with free hours

Menu choice: `3`

Input:
- Hours needed: `8`

Expected output:

```text
Faculty available for 8 hours:
Dr. Iyer : 12 hours free
```
