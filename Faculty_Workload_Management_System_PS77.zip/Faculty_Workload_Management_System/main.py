"""
Faculty Workload Management System
PS No. 77 | Python 3 | Pandas

Run:
    python main.py
"""

from pathlib import Path
import pandas as pd

DATA_FILE = Path(__file__).with_name("workload.csv")
MAX_HOURS = 16
REQUIRED_COLUMNS = ["Faculty", "Subject", "Hours"]


def load_workload():
    """Load workload.csv and validate its structure and values."""
    if not DATA_FILE.exists():
        print(f"Error: {DATA_FILE.name} was not found.")
        print("Keep workload.csv in the same folder as main.py.")
        return None

    try:
        df = pd.read_csv(DATA_FILE)
    except (pd.errors.ParserError, UnicodeDecodeError, OSError) as exc:
        print(f"Error reading {DATA_FILE.name}: {exc}")
        return None

    missing = [column for column in REQUIRED_COLUMNS if column not in df.columns]
    if missing:
        print("Error: workload.csv must contain these columns: Faculty, Subject, Hours.")
        return None

    if df.empty:
        return pd.DataFrame(columns=REQUIRED_COLUMNS)

    df = df[REQUIRED_COLUMNS].copy()
    df["Faculty"] = df["Faculty"].astype(str).str.strip()
    df["Subject"] = df["Subject"].astype(str).str.strip()
    df["Hours"] = pd.to_numeric(df["Hours"], errors="coerce")

    if df[["Faculty", "Subject", "Hours"]].isna().any().any():
        print("Error: workload.csv contains missing or invalid values.")
        return None
    if (df["Faculty"] == "").any() or (df["Subject"] == "").any():
        print("Error: Faculty and Subject names cannot be empty.")
        return None
    if (df["Hours"] <= 0).any() or ((df["Hours"] % 1) != 0).any():
        print("Error: Hours in workload.csv must be positive whole numbers.")
        return None

    df["Hours"] = df["Hours"].astype(int)
    return df


def save_workload(df):
    """Save the current workload to CSV."""
    try:
        df[REQUIRED_COLUMNS].to_csv(DATA_FILE, index=False)
        return True
    except OSError as exc:
        print(f"Error saving workload: {exc}")
        return False


def get_workload_summary(df):
    """Return one summary row per faculty member."""
    if df.empty:
        return pd.DataFrame(columns=["Faculty", "Total Hours", "Free Hours", "Status"])

    totals = (
        df.groupby("Faculty", sort=False)["Hours"]
        .sum()
        .reset_index(name="Total Hours")
    )
    totals["Free Hours"] = (MAX_HOURS - totals["Total Hours"]).clip(lower=0)
    totals["Status"] = totals["Total Hours"].apply(
        lambda total: "OVERLOADED" if total > MAX_HOURS else "OK"
    )
    return totals


def show_workload_summary(df):
    """Print total hours, free hours, and overloaded status."""
    summary = get_workload_summary(df)
    if summary.empty:
        print("\nNo workload records found.")
        return

    print("\nFaculty Workload Summary")
    print("-" * 34)
    for _, row in summary.iterrows():
        faculty = row["Faculty"]
        total = int(row["Total Hours"])
        free = int(row["Free Hours"])
        if total > MAX_HOURS:
            print(f"{faculty} : {total} hours - OVERLOADED by {total - MAX_HOURS} hours")
        else:
            print(f"{faculty} : {total} hours ({free} free)")


def assign_subject(df, faculty, subject, hours):
    """
    Assign a subject only when hours are a positive whole number and
    the faculty member's total will not exceed the 16-hour limit.
    Returns (updated_dataframe, success_boolean, message).
    """
    faculty = faculty.strip()
    subject = subject.strip()

    if not faculty or not subject:
        return df, False, "Faculty and subject names cannot be empty."

    if isinstance(hours, bool) or not isinstance(hours, int) or hours <= 0:
        return df, False, "Hours must be a positive whole number."

    current_total = int(df.loc[df["Faculty"].str.casefold() == faculty.casefold(), "Hours"].sum())
    new_total = current_total + hours

    if new_total > MAX_HOURS:
        return (
            df,
            False,
            f"Cannot assign: {faculty} would have {new_total} hours, exceeding the 16-hour limit.",
        )

    # Keep the original spelling of an existing faculty member.
    matches = df.loc[df["Faculty"].str.casefold() == faculty.casefold(), "Faculty"]
    if not matches.empty:
        faculty = matches.iloc[0]

    new_row = pd.DataFrame([{"Faculty": faculty, "Subject": subject, "Hours": hours}])
    updated = pd.concat([df, new_row], ignore_index=True)
    return updated, True, f"Assigned. {faculty} now has {new_total} hours (limit reached)." if new_total == MAX_HOURS else f"Assigned. {faculty} now has {new_total} hours."


def find_faculty_with_free_hours(df, hours_needed):
    """Return faculty members who have at least hours_needed free hours."""
    if isinstance(hours_needed, bool) or not isinstance(hours_needed, int) or hours_needed <= 0:
        raise ValueError("Hours needed must be a positive whole number.")

    summary = get_workload_summary(df)
    if summary.empty:
        return summary
    return summary.loc[
        (summary["Status"] != "OVERLOADED") &
        (summary["Free Hours"] >= hours_needed)
    ].reset_index(drop=True)


def read_positive_whole_number(prompt):
    """Read and validate a positive integer from the console."""
    raw = input(prompt).strip()
    try:
        value = int(raw)
    except ValueError:
        return None
    if value <= 0:
        return None
    return value


def run_menu():
    df = load_workload()
    if df is None:
        return

    while True:
        print("\n===== Faculty Workload Management System =====")
        print("1. Show workload summary")
        print("2. Assign a new subject")
        print("3. Find faculty with free hours")
        print("4. Exit")
        choice = input("Enter your choice (1-4): ").strip()

        if choice == "1":
            show_workload_summary(df)

        elif choice == "2":
            faculty = input("Enter faculty name: ").strip()
            subject = input("Enter subject name: ").strip()
            hours = read_positive_whole_number("Enter hours: ")
            if hours is None:
                print("Hours must be a positive whole number.")
                continue

            updated, success, message = assign_subject(df, faculty, subject, hours)
            print(message)
            if success and save_workload(updated):
                df = updated

        elif choice == "3":
            hours_needed = read_positive_whole_number("Hours needed: ")
            if hours_needed is None:
                print("Hours needed must be a positive whole number.")
                continue

            available = find_faculty_with_free_hours(df, hours_needed)
            print(f"\nFaculty available for {hours_needed} hours:")
            if available.empty:
                print("No faculty member has enough free hours.")
            else:
                for _, row in available.iterrows():
                    print(f"{row['Faculty']} : {int(row['Free Hours'])} hours free")

        elif choice == "4":
            print("Exiting Faculty Workload Management System.")
            break

        else:
            print("Invalid choice. Please enter a number from 1 to 4.")


if __name__ == "__main__":
    run_menu()
