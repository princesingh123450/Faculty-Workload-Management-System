# Faculty Workload Management System

**PS No.:** 77  
**Course:** B.Tech Computer Science and Engineering — First Semester  
**Language:** Python 3  
**Concepts:** Pandas, dictionaries/dataframes, functions, validation, CSV file handling

## Problem statement

Read `workload.csv` using Pandas. Calculate total weekly hours for each faculty member using a maximum workload limit of 16 hours. Mark faculty above the limit as `OVERLOADED`, allow new subject assignments only if the total will not exceed 16 hours, and find faculty members with enough free hours.

## Project files

- `main.py` — complete Python program and console menu
- `workload.csv` — starting sample data
- `requirements.txt` — Python dependency
- `TEST_CASES.md` — manual test steps and expected results

## Requirements

- Python 3
- Pandas

Install Pandas:

```bash
python -m pip install -r requirements.txt
```

## Run the project

Open a terminal in this folder and run:

```bash
python main.py
```

Choose:
1. Show workload summary
2. Assign a new subject
3. Find faculty with free hours
4. Exit

## Starting data and expected summary

The supplied CSV contains the six workload rows from the project brief. The expected starting summary is:

```text
Dr. Sharma : 11 hours (5 free)
Dr. Verma : 18 hours - OVERLOADED by 2 hours
Dr. Iyer : 4 hours (12 free)
```

**Note:** Successful assignments are saved back into `workload.csv`. To repeat a test from the original starting state, restore the six starting rows shown in `workload.csv` below or re-download the original project ZIP.

## GitHub upload

1. Create a repository named `faculty-workload-management-system`.
2. Upload `main.py`, `workload.csv`, `requirements.txt`, `README.md`, and `TEST_CASES.md`.
3. Add a short repository description: `Python and Pandas project to manage faculty weekly workload.`
